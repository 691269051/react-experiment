import styled, { css } from 'styled-components'

export const TemplateStyled = styled.div`
    ${({ theme = {} }) => {
        return css``
    }}
`
